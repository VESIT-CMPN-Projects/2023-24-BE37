# Fetal brain abnormality classification > 2023-08-13 2:42pm
https://universe.roboflow.com/computer-vision-m75wg/fetal-brain-abnormality-classification

Provided by a Roboflow user
License: CC BY 4.0

